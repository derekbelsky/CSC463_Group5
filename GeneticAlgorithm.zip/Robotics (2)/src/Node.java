import java.util.ArrayList;
import java.util.Random;

/**********************************************
 * Title: Node                                *
 * Authors: Derek Belsky, Emmitt Frankenberry *
 * Purpose: This is a class that should be    *
 * to create trees                            *
 **********************************************/ 

public class Node
{
    private ArrayList<Node> children = null;
    private int value;

    public Node(int value)
    {
        this.children = new ArrayList<>();
        this.value = value;
    }
    
   /**********************************************
	* Title: addChild	                         *
	* Purpose: This method adds a child to a     * 
	* current Node                               *
	* Parameter(s) Node child - the node in which*
	* you want to add children to                * 
	**********************************************/ 
    public void addChild(Node child)
    {
        children.add(child);
        //getValue();
    }
   /**********************************************
	* Title: getValue	                         *
	* Purpose: getter for value in Node          *
	* return: value                              *
	**********************************************/ 
    public int getValue() {
    	return value;
    }
   /**********************************************
	* Title: getValue	                         *
	* Purpose: getter for children in Node       *
	* return children                            *
	**********************************************/ 
    public ArrayList<Node> children() {
    	return children;
    }
    
   /**********************************************
	* Title: mutate   	                         *
	* Purpose: will change the tree so it will   * 
	* change one node to a random number.        *
	* parameter int v - index of the Node that   *
	* you want to replace                        *
	**********************************************/ 
    public void mutate(int v) {
    	if(value<4) {
    		if(v>=4&&v<6) {
    			children.remove(1);
    		}else if(v>=6) {
    			children.remove(1);
    			children.remove(0);
    		}
    	}else if(value<6) {
    		if(v<4) {
    			Random rand = new Random();
    			int n = rand.nextInt(12);
    			Node child1 = new Node(n);
    			children.add(child1);
    			buildTree1(child1);
    		}else if(v>=6) {
    			children.remove(0);
    		}
    	}else if(value>=6) {
    		if(v<4) {
    			Random rand = new Random();
    			int n = rand.nextInt(12);
    			Node child1 = new Node(n);
    			children.add(child1);
    			buildTree1(child1);
    			
    			Random rand1 = new Random();
    			int b = rand1.nextInt(12);
    			Node child2 = new Node(b);
    			children.add(child2);
    			buildTree1(child2);
    		}else if(v<6) {
    			Random rand = new Random();
    			int n = rand.nextInt(12);
    			Node child1 = new Node(n);
    			children.add(child1);
    			if(n<4) {
    				child1.addChild(buildTree1(child1));
    				child1.addChild(buildTree1(child1));
    			}else if(n<6) {
    				child1.addChild(buildTree1(child1));
    			}
    		}
    	}
    	value = v;
    	
    }
    /**********************************************
	 * Purpose: This method build a tree          *
	 * recursively from a given post order list.  *
	 *                                            *
	 * Parameter(s): Node root - starting root    *
	 * from which tree will be built              * 
	 **********************************************/
    
    public Node buildTree1(Node root) {
		Random rand = new Random();
		int value = rand.nextInt(12);
		Node child = new Node(value);
		if(value<4) {
			child.addChild(buildTree1(child));
			child.addChild(buildTree1(child));
		}else if(value<6) {
			child.addChild(buildTree1(child));
		}
		//else if
		return child;
	}
	
    /**********************************************
	 * Purpose: Will replace the any subtree with *
	 * a different one                            *
	 *                                            *
	 * Parameter(s): Node root - tree that will   *
	 * replace the existing tree                  * 
	 **********************************************/
    public void replace(Node subtree) {
    	for(int i=children.size()-1; !children.isEmpty(); i--) {
    		children.remove(i);
    	}
    	value = subtree.getValue();
    	ArrayList<Node> childs = subtree.children();
    	for(int i=0; i<childs.size();i++) {
    		children.add(childs.get(i));
    	}
    }
    
    /**********************************************
	 * Purpose: This function prints the tree     *
	 * using its function representatives         *
	 *                                            *
	 * Parameter(s):                              *
	 * Node root - tree that you'd like to print  *  
	 **********************************************/
	public void printCode(Node root){
		ArrayList<Node> childs = root.children();
		for(int i=0; i<childs.size(); i++) {
			printCode(childs.get(i));
		}
		int value = root.getValue();
		switch(value)
		{
			case 0:
				System.out.println("doTwoCloseFar");
				break;
			case 1:
				System.out.println("doTwoFarClose");
				break;
			case 2:
				System.out.println("doTwoCloseClose");
				break;
			case 3:
				System.out.println("doTwoFarFar");
				break;
			case 4:
				System.out.println("closeToWall");
				break;
			case 5:
				System.out.println("farFromWall");
				break;
			case 6:
				System.out.println("goForward");
				break;
			case 7:
				System.out.println("turnRight");
				break;
			case 8:
				System.out.println("turnLeft");
				break;
			case 9:
				System.out.println("backup");
				break;
			case 10:
				System.out.println("turnParallelToPosition");
				break;
			case 11:
				System.out.println("turnSquareWithWall");
				break;
			default:
				break;
				
		}
		
	}
	
	/**********************************************
	 * Purpose: This function print the tree      *
	 * using its numberical representatives       *
	 *                                            *
	 * Parameter(s):                              *
	 * Node root - tree that you'd like to print  *  
	 **********************************************/
	public void printNum(Node root){
		ArrayList<Node> childs = root.children();
		for(int i=0; i<childs.size(); i++) {
			printNum(childs.get(i));
		}
		int value = root.getValue();
		System.out.println(value);
	}
	
   
	
	

}
