import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**********************************************
 * Title: Task 3: Mutations                   *
 * Authors: Derek Belsky, Emmitt Frankenberry *
 * Purpose: The purpose of this program is to *
 * input one post order tree and swap out     *
 * a random node                              *
 **********************************************/ 
public class Mutations 
{
	 static int[] array = new int[1024];
	 static int daNumber = 0;
   /**********************************************
	* Title: main	                             *
	* Purpose: The purpose of main is to create  *
	* arrays and build trees to be used in the   *
	* replace functions                          *
	**********************************************/ 
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		Node root;
		int i=0;
		do {
			array[i] = sc.nextInt();
			i++;
		}while(sc.hasNextInt());
		sc.close();

		root = new Node(array[i-1]);
		daNumber = i - 2;
		buildTree(root);
		
		Random rand = new Random();
		int value = rand.nextInt(i);
		
		searchTree(root, value, 0);
		root.printNum(root);
		System.out.println();
		root.printCode(root);
		
	}
	
	 /**********************************************
	  * Purpose: This method build a tree          *
	  * recursively from a given post order list.  *
	  *                                            *
	  * Parameter(s): Node root - starting root    *
	  * from which tree will be built              * 
	  **********************************************/
	public static void buildTree(Node root) {
			if(root.getValue()<4) {
				Node child1 = new Node(array[daNumber]);
				root.addChild(child1);
				daNumber--;
				buildTree(child1);
				Node child2 = new Node(array[daNumber]);
				root.addChild(child2);
				daNumber--;
				buildTree(child2);
			}else if(root.getValue()<6) {
				Node child1 = new Node(array[daNumber]);
				root.addChild(child1);
				daNumber--;
				buildTree(child1);
			}
	}
	
	/**********************************************
	 * Purpose: This method searches the tree for * 
	 * a indexed node                             * 
	 *                                            *
	 * Parameter(s):                              * 
	 * Node root - the tree you'd like to search  *  
	 * int value - the indexed location of the    *
	 * Node you are searching for                 *
	 * int i - starting index                     *  
	 *                                            *  
	 * Return: Node - the Node that was found     *
	 *        at the specified index              *
	 **********************************************/
	public static void searchTree(Node root, int value, int i) {
		if(value!=i) {
			if(root.getValue()<6) {
				ArrayList<Node> childs = root.children();
				for(int index =1; index-1<childs.size(); index++) {
					Node child1 = childs.get(index-1);
					searchTree(child1, value, i+index);
				}
			}
		}else if(value==i) {
			Random rand = new Random();
			int v = rand.nextInt(12);
			root.mutate(v);
			
		}
		
	}
}
