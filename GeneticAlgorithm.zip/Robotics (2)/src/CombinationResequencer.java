import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**********************************************
 * Title: Task 4: Swapping two Subtrees       *
 * Authors: Derek Belsky, Emmitt Frankenberry *
 * Purpose: The purpose of this program is to *
 * input two post order trees and swap two    *
 * subtrees.                                  *
 **********************************************/ 

public class CombinationResequencer {

	static int[] array = new int[1024];
	static int daNumber = 0;
   /**********************************************
	* Title: main	                             *
	* Purpose: The purpose of main is to create  *
	* arrays and build trees to be used in the   *
	* replace functions                          *
	**********************************************/ 
	public static void main(String[] args) {
		int ar1;
	    int ar2;
		Scanner sc = new Scanner(System.in);
		int i=0;
		do {
			array[i] = sc.nextInt();
			i++;
		}while(sc.hasNextInt());
		sc.next();
		
		daNumber = i-1;
		ar1 =daNumber;
		Node root1 = new Node(array[daNumber]);
		daNumber--;
		buildTree(root1);
		
		daNumber = i - 1;
		Node temproot1 = new Node(array[daNumber]);
		daNumber--;
		buildTree(temproot1);
		
		
		for(int j = 0; j<1024; j++)
		{
			array[j] = 0;
		}
		
		i=0;
		do {
			array[i] = sc.nextInt();
			i++;
		}while(sc.hasNextInt());
		sc.close();
		
		daNumber = i - 1;
		Node temproot2 = new Node(array[daNumber]);
		daNumber--;
		buildTree(temproot2);
		
		daNumber = i-1;
		ar2 = daNumber;
		Node root2 = new Node(array[daNumber]);
		daNumber--;
		buildTree(root2);
		
		
		Random rand = new Random();
		int v = rand.nextInt(ar2+1);
		
		Random rand1 = new Random();
		int n = rand1.nextInt(ar1+1);
		
		
		Node subTree2 = searchTreeNode(temproot2, v, 0);
		searchTreeReplace(temproot1, n, 0, subTree2);
		temproot1.printNum(temproot1);
		System.out.println();
		
		Node subTree1 = searchTreeNode(root1, n, 0);
		searchTreeReplace(root2, v, 0, subTree1);
		root2.printNum(root2);
		
		
		
	}
	/**********************************************
	 * Purpose: This method build a tree          *
	 * recursively from a given post order list.  *
	 *                                            *
	 * Parameter(s): Node root - starting root    *
	 * from which tree will be built              * 
	 **********************************************/
	
	private static void buildTree(Node root) {
		// TODO Auto-generated method stub
		if(root.getValue()<4) {
			Node child1 = new Node(array[daNumber]);
			root.addChild(child1);
			daNumber--;
			buildTree(child1);
			Node child2 = new Node(array[daNumber]);
			root.addChild(child2);
			daNumber--;
			buildTree(child2);
		}else if(root.getValue()<6) {
			Node child1 = new Node(array[daNumber]);
			root.addChild(child1);
			daNumber--;
			buildTree(child1);
		}
	}

	/**********************************************
	 * Purpose: This method searches the tree for * 
	 * a indexed node                             * 
	 *                                            *
	 * Parameter(s):                              * 
	 * Node root - the tree you'd like to search  *  
	 * int value - the indexed location of the    *
	 * Node you are searching for                 *
	 * int i - starting index                     *  
	 *                                            *  
	 * Return: Node - the Node that was found     *
	 *        at the specified index              *
	 **********************************************/
	private static Node searchTreeNode(Node root, int value, int i) {
		if(value!=i) {
			if(root.getValue()<6) {
				Node tommyBoy=null;
				ArrayList<Node> childs = root.children();
				for(int index =1; index-1<childs.size(); index++) {
					Node child1 = childs.get(index-1);
					tommyBoy = searchTreeNode(child1, value, i+index);
				}
				return tommyBoy;
			}
		}else{
			return root;
			
		}
		return root;
		
	}
	
	/**********************************************
	 * Purpose: This method will take one tree and*
	 * replace a specified index with another     *
	 * subtree                                    *
	 *                                            *
	 * Parameter(s):                              *
	 * Node root - the tree you'd like to replace *
	 * a node in                                  * 
	 * int value - the indexed location of the    *
	 * Node that is being replaced                *
	 * int i - starting index                     *
	 * Node subroot - subTree that is going to    * 
	 * in new tree                                *   
	 **********************************************/
	private static void searchTreeReplace(Node root, int value, int i, Node subRoot) {
		if(value!=i) {
			if(root.getValue()<6) {
				ArrayList<Node> childs = root.children();
				for(int index =1; index-1<childs.size(); index++) {
					Node child1 = childs.get(index-1);
					searchTreeReplace(child1, value, i+index, subRoot);
				}
			}
		}else if(value==i) {
			root.replace(subRoot);
			
		}
		
	}

}
