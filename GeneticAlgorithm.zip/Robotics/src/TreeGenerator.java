import java.util.ArrayList;
import java.util.Random;
/**********************************************
 * Title: Task 2: Tree Generator              *
 * Authors: Derek Belsky, Emmitt Frankenberry *
 * Purpose: The purpose of this program is to *
 * create a tree with random functions        *
 **********************************************/ 

public class TreeGenerator {

	/* List of things
	 * 0 - doTwoCloseFar **
	 * 1 - doTwoFarClose **
	 * 2 - doTwoCloseClose **
	 * 3 - doTwoFarFar **
	 * 4 - closeToWall *
	 * 5 - farFromWall *
	 * 6 - 
	 * 7 - 
	 * 8 -
	 * 9 - 
	 * 10 - 
	 * 11 - 
	 * Stars at the end indicate children
	 */
   /**********************************************
	* Title: main	                             *
	* Purpose: The purpose of main is to create  *
	* arrays and build trees to be used in the   *
	* replace functions                          *
	**********************************************/ 
	int array[] = new int[100];
	public static void main(String args[]) {
		Random rand = new Random();
		int value = rand.nextInt(12);
		Node root = new Node(value);
		if(value<4) {
			root.addChild(buildTree(root));
			root.addChild(buildTree(root));
		}else if(value<6) {
			root.addChild(buildTree(root));
		}
		
		
		root.printNum(root);
		System.out.println();
		root.printCode(root);
	
	    
	}
	/**********************************************
	 * Purpose: This method build a tree          *
	 * recursively from a given post order list.  *
	 *                                            *
	 * Parameter(s): Node root - starting root    *
	 * from which tree will be built              * 
	 **********************************************/
	public static Node buildTree(Node root) {
		Random rand = new Random();
		int value = rand.nextInt(12);
		Node child = new Node(value);
		if(value<4) {
			child.addChild(buildTree(child));
			child.addChild(buildTree(child));
		}else if(value<6) {
			child.addChild(buildTree(child));
		}
		//else if
		return child;
	}
	

	
	
}
