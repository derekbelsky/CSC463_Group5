import java.util.ArrayList;

/**********************************************
 * Title: DummyNode                           *
 * Authors: Derek Belsky, Emmitt Frankenberry *
 * Purpose: This is another class that should *
 * be used to create trees if a copy of a     *
 * Node needs to be made                      *
 **********************************************/ 
public class DummyNode {

	private ArrayList<DummyNode> children = null;
    private int value;
	public DummyNode(int value){
		this.children = new ArrayList<>();
		this.value = value;
	}
	
	/**********************************************
	* Title: getValue	                         *
	* Purpose: getter for value in Node          *
	* return: value                              *
	**********************************************/ 
	public int getValue() {
		// TODO Auto-generated method stub
		return value;
	}
	
	/**********************************************
	* Title: getValue	                         *
	* Purpose: getter for children in Node       *
	* return children                            *
	**********************************************/ 
	public ArrayList<DummyNode> children() {
		// TODO Auto-generated method stub
		return children;
	}
	
   /**********************************************
	* Title: addChild	                         *
	* Purpose: This method adds a child to a     * 
	* current DummyNode                          *
	* Parameter(s) DummyNode child - the node in *
	* which you want to add children to          * 
	**********************************************/ 
	public void addChild(DummyNode child)
    {
        children.add(child);
        //getValue();
    }
	
	public void replace(DummyNode subtree) {
    	for(int i=children.size()-1; !children.isEmpty(); i--) {
    		children.remove(i);
    	}
    	value = subtree.getValue();
    	ArrayList<DummyNode> childs = subtree.children();
    	for(int i=0; i<childs.size();i++) {
    		children.add(childs.get(i));
    	}
    }
	
	public void printCode(DummyNode root){
		ArrayList<DummyNode> childs = root.children();
		for(int i=0; i<childs.size(); i++) {
			printCode(childs.get(i));
		}
		int value = root.getValue();
		switch(value)
		{
			case 0:
				System.out.println("doTwoCloseFar");
				break;
			case 1:
				System.out.println("doTwoFarClose");
				break;
			case 2:
				System.out.println("doTwoCloseClose");
				break;
			case 3:
				System.out.println("doTwoFarFar");
				break;
			case 4:
				System.out.println("closeToWall");
				break;
			case 5:
				System.out.println("farFromWall");
				break;
			case 6:
				System.out.println("goForward");
				break;
			case 7:
				System.out.println("turnRight");
				break;
			case 8:
				System.out.println("turnLeft");
				break;
			case 9:
				System.out.println("backup");
				break;
			case 10:
				System.out.println("turnParallelToPosition");
				break;
			case 11:
				System.out.println("turnSquareWithWall");
				break;
			default:
				break;
				
		}
		
	}
	
	/**********************************************
	 * Purpose: This function print the tree      *
	 * using its numberical representatives       *
	 *                                            *
	 * Parameter(s):                              *
	 * Node root - tree that you'd like to print  *  
	 **********************************************/
	public void printNum(DummyNode root){
		ArrayList<DummyNode> childs = root.children();
		for(int i=0; i<childs.size(); i++) {
			printNum(childs.get(i));
		}
		int value = root.getValue();
		System.out.println(value);
	}
}
